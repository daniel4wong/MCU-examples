### ATCommandTester

`Test AT commands for GSM modems over serial (RS232/UART) connection with lots of options.`

* Ported and cleaned up version of the ATCommandTester from m2msupport.net
* Standalone & offline - no Java Applet security bullshit
* Still lots of optimizations can be done, e.g. ATCommandTester.java >10k lines!!! seriously?! OMG!
* Grab and enjoy!

***Windows users***

`Run run_x32.bat file to launch the program on 32-bit Windows.`

`Run run_x64.bat file to launch the program on 64-bit Windows.`

***Screenshots***

<img src="img/screen1.png" width="500">
